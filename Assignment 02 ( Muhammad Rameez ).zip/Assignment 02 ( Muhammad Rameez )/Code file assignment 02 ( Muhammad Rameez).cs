﻿string moral1 = "Union is strength.";
string moral2 = "United we stand, divided we fall.";
string title = " old farmer";
string son = "his sons";
char a = 'A';
char b = 'n';
int tsons = 4;
float space = 89.732f;
double memory = 78.298712;
decimal address = 3.3498798729374m;

Console.WriteLine("\t"+a+b+title+" and "+son);
Console.WriteLine("\nOnce there was "+a+b+title+ ". He had "+tsons +" sons"+
".They were very lazy and did not help their father in the field.\n"+
"They always quarreled among themselves. He always tried to mend their way but in vain."+
"One day their father fell ill.\nHe was on his death bed. He wanted his sons to be hard working."+
"He called "+son+" and asked them to bring  of sticks.\nHe asked each of "+son+" to break the bundle." +
"Tried to break the bundle but failed.\nThen they never quarreled again." +


/*"The father now untied the bundle and asked them to break one stick each.\n"+
"Each one of them was able to break a single stick.The father advised\n "+son+
"that like the bundle of sticks learnt a lesson.\n "+
*/
"\n\nMoral: " + moral1 + "\n\t&\n" + moral2 );
Console.WriteLine("\n\nSome usefull informations\n Total Space: "+space+"\n Total Memory: "+memory +"\n Total Address: "+address);